package midtest;

import java.awt.FileDialog;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;

public class A1802100265 {

	public static void main(String[] args) {
		MyMenu my = new MyMenu();
		my.makeMenu();
		my.display();
	}

}

class MyMenu extends JFrame implements ActionListener{
	
	JMenuBar bar;
	JMenu File, Add, Notice;
	JMenuItem nw, open, save, exit; // ����
	JMenuItem canvas, calc; // Add �׸���, ����
	JMenuItem noti; // Notice �˸�
	JMenu info; // ����
	JMenuItem name, number; // �̸�,�й�

	JTextArea ta;
	
	FileDialog neew, op, sv; // ����, �����ϱ� ��ȭ����
	
	MyMenu() {
		
	bar = new JMenuBar();
	
	File = new JMenu("����");
	Add = new JMenu("Add");
	Notice = new JMenu("Notice");
	
	info = new JMenu("����");

	//
	
	nw = new JMenuItem("����");
	nw.setAccelerator(KeyStroke.getKeyStroke('N', ActionEvent.CTRL_MASK));
	nw.addActionListener(this);
	
	open = new JMenuItem("����");
	op = new FileDialog(this, "� ������ ������?", FileDialog.SAVE);
	open.setAccelerator(KeyStroke.getKeyStroke('O', ActionEvent.CTRL_MASK));
	open.addActionListener(this);
	
	save = new JMenuItem("����");
	sv = new FileDialog(this, "������ ���ϸ��� �����ּ���", FileDialog.SAVE);
	save.setAccelerator(KeyStroke.getKeyStroke('S', ActionEvent.CTRL_MASK));
	save.addActionListener(this);
	
	exit = new JMenuItem("������");
	exit.setAccelerator(KeyStroke.getKeyStroke('Q', ActionEvent.CTRL_MASK));
	exit.addActionListener(this);
	
	//
	
	canvas = new JMenuItem("�׸���");
	canvas.addActionListener(this);
	calc = new JMenuItem("����");
	calc.addActionListener(this);
	
	//
	
	noti = new JMenuItem("���ǻ���");
	noti.addActionListener(this);
	
	name = new JMenuItem("�赵��");
	number = new JMenuItem("1802100265");

	//
	
	ta = new JTextArea(10, 50);
	add(ta);
	}

public void actionPerformed(ActionEvent e) {
		if(e.getSource() == exit)
		{
			System.exit(0);
		}
		if(e.getSource() == nw)
		{
			ta.setText("");
		}
		if(e.getSource() == open)
		{
			op.setVisible(true);
		}
		if(e.getSource() == save)
		{
			sv.setVisible(true);
		}
		
		if(e.getSource() == calc)
		{
			Calc calc = new Calc();
			calc.display();
		}
		if(e.getSource() == canvas)
		{
			MyDrawFrame df = new MyDrawFrame();
			df.display();
		}
		if(e.getSource() == noti)
		{
			MyDialog dial = new MyDialog();
		}
	}
	
	void makeMenu() {
	
		bar.add(File); bar.add(Add); bar.add(Notice);
		File.add(nw); File.add(open); File.add(save); File.add(exit);
		Add.add(canvas); Add.add(calc);
		Notice.add(noti); Notice.add(info);
		info.add(name); info.add(number);
		setJMenuBar(bar);
		}
	
	class MyDialog extends JDialog {
		
		JLabel label;
		
		public MyDialog() {
			label = new JLabel("                                   �ȳ��ϼ���");
			add(label);
			setLayout(new GridLayout());
			setTitle("Dialog");
			setSize(300, 200);
			setVisible(true);
		}
	}

	void display() {
		setTitle("ȭ��");
		setExtendedState(MAXIMIZED_BOTH); // MAXIMIZED_VERT MAXIMIZED_BOTH 
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
}