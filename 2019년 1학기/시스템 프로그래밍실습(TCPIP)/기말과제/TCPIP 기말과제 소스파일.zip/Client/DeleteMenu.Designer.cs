﻿namespace BonResto
{
    partial class DeleteMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem19 = new System.Windows.Forms.ListViewItem(new string[] {
            "콜라",
            "콜라",
            "1000"}, 0);
            System.Windows.Forms.ListViewItem listViewItem20 = new System.Windows.Forms.ListViewItem(new string[] {
            "사이다",
            "사이다",
            "1000"}, 1);
            System.Windows.Forms.ListViewItem listViewItem25 = new System.Windows.Forms.ListViewItem(new string[] {
            "채끝살",
            "채끝살",
            "50000"}, 0);
            System.Windows.Forms.ListViewItem listViewItem26 = new System.Windows.Forms.ListViewItem(new string[] {
            "치즈",
            "치즈",
            "1000"}, 1);
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeleteMenu));
            System.Windows.Forms.ListViewItem listViewItem27 = new System.Windows.Forms.ListViewItem(new string[] {
            "짜파게티",
            "짜파게티",
            "1000"}, 0);
            System.Windows.Forms.ListViewItem listViewItem28 = new System.Windows.Forms.ListViewItem(new string[] {
            "너구리",
            "너구리",
            "1500"}, 1);
            this.label9 = new System.Windows.Forms.Label();
            this.listView3 = new System.Windows.Forms.ListView();
            this.BPanel = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.listView2 = new System.Windows.Forms.ListView();
            this.SMPanel = new System.Windows.Forms.Panel();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.listView1 = new System.Windows.Forms.ListView();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.MMPanel = new System.Windows.Forms.Panel();
            this.Beverage = new System.Windows.Forms.ToolStripMenuItem();
            this.SideMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.MainMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuInfo = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.BPanel.SuspendLayout();
            this.SMPanel.SuspendLayout();
            this.MMPanel.SuspendLayout();
            this.MenuInfo.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(276, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 15);
            this.label9.TabIndex = 2;
            this.label9.Text = "음료메뉴";
            this.label9.Visible = false;
            // 
            // listView3
            // 
            this.listView3.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem19,
            listViewItem20});
            this.listView3.Location = new System.Drawing.Point(6, 42);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(330, 380);
            this.listView3.TabIndex = 0;
            this.listView3.UseCompatibleStateImageBehavior = false;
            // 
            // BPanel
            // 
            this.BPanel.Controls.Add(this.label9);
            this.BPanel.Controls.Add(this.label10);
            this.BPanel.Controls.Add(this.listView3);
            this.BPanel.Location = new System.Drawing.Point(772, 34);
            this.BPanel.Name = "BPanel";
            this.BPanel.Size = new System.Drawing.Size(361, 425);
            this.BPanel.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 15);
            this.label10.TabIndex = 1;
            this.label10.Text = "메뉴목록";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(276, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 15);
            this.label8.TabIndex = 2;
            this.label8.Text = "사이드메뉴";
            this.label8.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "메뉴목록";
            // 
            // listView2
            // 
            this.listView2.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem25,
            listViewItem26});
            this.listView2.Location = new System.Drawing.Point(6, 42);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(330, 380);
            this.listView2.TabIndex = 0;
            this.listView2.UseCompatibleStateImageBehavior = false;
            // 
            // SMPanel
            // 
            this.SMPanel.Controls.Add(this.label8);
            this.SMPanel.Controls.Add(this.label6);
            this.SMPanel.Controls.Add(this.listView2);
            this.SMPanel.Location = new System.Drawing.Point(395, 34);
            this.SMPanel.Name = "SMPanel";
            this.SMPanel.Size = new System.Drawing.Size(361, 425);
            this.SMPanel.TabIndex = 14;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "00.jpg");
            this.imageList1.Images.SetKeyName(1, "01.jpg");
            // 
            // listView1
            // 
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem27,
            listViewItem28});
            this.listView1.LargeImageList = this.imageList1;
            this.listView1.Location = new System.Drawing.Point(6, 42);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(330, 380);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(102, 370);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 47);
            this.button1.TabIndex = 3;
            this.button1.Text = "삭제";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(304, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "주메뉴";
            this.label7.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "메뉴목록";
            // 
            // MMPanel
            // 
            this.MMPanel.Controls.Add(this.label7);
            this.MMPanel.Controls.Add(this.label1);
            this.MMPanel.Controls.Add(this.listView1);
            this.MMPanel.Location = new System.Drawing.Point(12, 34);
            this.MMPanel.Name = "MMPanel";
            this.MMPanel.Size = new System.Drawing.Size(361, 425);
            this.MMPanel.TabIndex = 12;
            // 
            // Beverage
            // 
            this.Beverage.Name = "Beverage";
            this.Beverage.Size = new System.Drawing.Size(51, 24);
            this.Beverage.Text = "음료";
            this.Beverage.Click += new System.EventHandler(this.Beverage_Click);
            // 
            // SideMenu
            // 
            this.SideMenu.Name = "SideMenu";
            this.SideMenu.Size = new System.Drawing.Size(96, 24);
            this.SideMenu.Text = "사이드메뉴";
            this.SideMenu.Click += new System.EventHandler(this.SideMenu_Click);
            // 
            // MainMenu
            // 
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(66, 24);
            this.MainMenu.Text = "주메뉴";
            this.MainMenu.Click += new System.EventHandler(this.MainMenu_Click);
            // 
            // MenuInfo
            // 
            this.MenuInfo.Controls.Add(this.button1);
            this.MenuInfo.Location = new System.Drawing.Point(1151, 34);
            this.MenuInfo.Name = "MenuInfo";
            this.MenuInfo.Size = new System.Drawing.Size(317, 425);
            this.MenuInfo.TabIndex = 13;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MainMenu,
            this.SideMenu,
            this.Beverage});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1482, 28);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // DeleteMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1482, 463);
            this.Controls.Add(this.BPanel);
            this.Controls.Add(this.SMPanel);
            this.Controls.Add(this.MMPanel);
            this.Controls.Add(this.MenuInfo);
            this.Controls.Add(this.menuStrip1);
            this.Name = "DeleteMenu";
            this.Text = "DeleteMenu";
            this.Load += new System.EventHandler(this.DeleteMenu_Load);
            this.BPanel.ResumeLayout(false);
            this.BPanel.PerformLayout();
            this.SMPanel.ResumeLayout(false);
            this.SMPanel.PerformLayout();
            this.MMPanel.ResumeLayout(false);
            this.MMPanel.PerformLayout();
            this.MenuInfo.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.Panel BPanel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.Panel SMPanel;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel MMPanel;
        private System.Windows.Forms.ToolStripMenuItem Beverage;
        private System.Windows.Forms.ToolStripMenuItem SideMenu;
        private System.Windows.Forms.ToolStripMenuItem MainMenu;
        private System.Windows.Forms.Panel MenuInfo;
        private System.Windows.Forms.MenuStrip menuStrip1;
    }
}